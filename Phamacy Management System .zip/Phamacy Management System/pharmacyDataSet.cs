﻿namespace Phamacy_Management_System {
    
    
    public partial class pharmacyDataSet {
        partial class compDataTable
        {
        }
    }
}

namespace Phamacy_Management_System.pharmacyDataSetTableAdapters {
    
    
    public partial class compTableAdapter {
    }
}
