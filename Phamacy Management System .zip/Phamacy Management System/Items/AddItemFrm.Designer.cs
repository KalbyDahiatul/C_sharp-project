﻿namespace Phamacy_Management_System
{
    partial class AddItemFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.addItemAddbtn = new System.Windows.Forms.Button();
            this.addItemCanclebtn = new System.Windows.Forms.Button();
            this.addItemBartxt = new System.Windows.Forms.TextBox();
            this.addItemScNametxt = new System.Windows.Forms.TextBox();
            this.addItemCompcomb = new System.Windows.Forms.ComboBox();
            this.addExDatedtp = new System.Windows.Forms.DateTimePicker();
            this.addItemTrdNametxt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.addItemDelcomb = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pieceQuanttxt = new System.Windows.Forms.TextBox();
            this.pillQuanttxt = new System.Windows.Forms.TextBox();
            this.tabQuanttxt = new System.Windows.Forms.TextBox();
            this.packQuanttxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.sellDfltPiecerdb = new System.Windows.Forms.RadioButton();
            this.sellDfltPackrdb = new System.Windows.Forms.RadioButton();
            this.sellDfltTabrdb = new System.Windows.Forms.RadioButton();
            this.sellDfltPillrdb = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.buyDfltPiecerdb = new System.Windows.Forms.RadioButton();
            this.buyDfltPackrdb = new System.Windows.Forms.RadioButton();
            this.buyDfltTabrdb = new System.Windows.Forms.RadioButton();
            this.buyDfltPillrdb = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.piecenum = new System.Windows.Forms.NumericUpDown();
            this.packnum = new System.Windows.Forms.NumericUpDown();
            this.tabnum = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.pillnum = new System.Windows.Forms.NumericUpDown();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.piecenum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packnum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabnum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pillnum)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(7, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Item Barcode";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(10, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Item Scientfic Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(10, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Company";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(386, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Expire date";
            // 
            // addItemAddbtn
            // 
            this.addItemAddbtn.BackColor = System.Drawing.Color.Teal;
            this.addItemAddbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemAddbtn.ForeColor = System.Drawing.Color.White;
            this.addItemAddbtn.Location = new System.Drawing.Point(292, 546);
            this.addItemAddbtn.Name = "addItemAddbtn";
            this.addItemAddbtn.Size = new System.Drawing.Size(85, 35);
            this.addItemAddbtn.TabIndex = 30;
            this.addItemAddbtn.Text = "Add";
            this.addItemAddbtn.UseVisualStyleBackColor = false;
            this.addItemAddbtn.Click += new System.EventHandler(this.addItemAddbtn_Click);
            // 
            // addItemCanclebtn
            // 
            this.addItemCanclebtn.BackColor = System.Drawing.Color.Teal;
            this.addItemCanclebtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.addItemCanclebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemCanclebtn.ForeColor = System.Drawing.Color.White;
            this.addItemCanclebtn.Location = new System.Drawing.Point(398, 546);
            this.addItemCanclebtn.Name = "addItemCanclebtn";
            this.addItemCanclebtn.Size = new System.Drawing.Size(85, 35);
            this.addItemCanclebtn.TabIndex = 31;
            this.addItemCanclebtn.Text = "Cancle";
            this.addItemCanclebtn.UseVisualStyleBackColor = false;
            this.addItemCanclebtn.Click += new System.EventHandler(this.addItemCanclebtn_Click);
            // 
            // addItemBartxt
            // 
            this.addItemBartxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemBartxt.ForeColor = System.Drawing.Color.Black;
            this.addItemBartxt.Location = new System.Drawing.Point(156, 20);
            this.addItemBartxt.Name = "addItemBartxt";
            this.addItemBartxt.Size = new System.Drawing.Size(218, 22);
            this.addItemBartxt.TabIndex = 0;
            this.addItemBartxt.TextChanged += new System.EventHandler(this.addItemBartxt_TextChanged);
            this.addItemBartxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.addItemBartxt_KeyPress);
            // 
            // addItemScNametxt
            // 
            this.addItemScNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemScNametxt.ForeColor = System.Drawing.Color.Black;
            this.addItemScNametxt.Location = new System.Drawing.Point(156, 53);
            this.addItemScNametxt.MaxLength = 40;
            this.addItemScNametxt.Name = "addItemScNametxt";
            this.addItemScNametxt.Size = new System.Drawing.Size(218, 22);
            this.addItemScNametxt.TabIndex = 2;
            this.addItemScNametxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.itmNamesKeyPress);
            // 
            // addItemCompcomb
            // 
            this.addItemCompcomb.BackColor = System.Drawing.Color.Teal;
            this.addItemCompcomb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addItemCompcomb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addItemCompcomb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemCompcomb.ForeColor = System.Drawing.Color.White;
            this.addItemCompcomb.FormattingEnabled = true;
            this.addItemCompcomb.Location = new System.Drawing.Point(156, 86);
            this.addItemCompcomb.Name = "addItemCompcomb";
            this.addItemCompcomb.Size = new System.Drawing.Size(218, 24);
            this.addItemCompcomb.TabIndex = 4;
            this.addItemCompcomb.SelectedIndexChanged += new System.EventHandler(this.addItemCompcomb_SelectedIndexChanged);
            // 
            // addExDatedtp
            // 
            this.addExDatedtp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addExDatedtp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.addExDatedtp.Location = new System.Drawing.Point(527, 53);
            this.addExDatedtp.Name = "addExDatedtp";
            this.addExDatedtp.Size = new System.Drawing.Size(234, 22);
            this.addExDatedtp.TabIndex = 3;
            // 
            // addItemTrdNametxt
            // 
            this.addItemTrdNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemTrdNametxt.ForeColor = System.Drawing.Color.Black;
            this.addItemTrdNametxt.Location = new System.Drawing.Point(527, 23);
            this.addItemTrdNametxt.MaxLength = 40;
            this.addItemTrdNametxt.Name = "addItemTrdNametxt";
            this.addItemTrdNametxt.Size = new System.Drawing.Size(234, 22);
            this.addItemTrdNametxt.TabIndex = 1;
            this.addItemTrdNametxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.itmNamesKeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(386, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(140, 16);
            this.label8.TabIndex = 19;
            this.label8.Text = "Item Trading Name";
            // 
            // addItemDelcomb
            // 
            this.addItemDelcomb.BackColor = System.Drawing.Color.Teal;
            this.addItemDelcomb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addItemDelcomb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addItemDelcomb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemDelcomb.ForeColor = System.Drawing.Color.White;
            this.addItemDelcomb.FormattingEnabled = true;
            this.addItemDelcomb.Location = new System.Drawing.Point(527, 89);
            this.addItemDelcomb.Name = "addItemDelcomb";
            this.addItemDelcomb.Size = new System.Drawing.Size(234, 24);
            this.addItemDelcomb.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Teal;
            this.label9.Location = new System.Drawing.Point(391, 92);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 16);
            this.label9.TabIndex = 21;
            this.label9.Text = "Delegate";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pieceQuanttxt);
            this.groupBox1.Controls.Add(this.pillQuanttxt);
            this.groupBox1.Controls.Add(this.tabQuanttxt);
            this.groupBox1.Controls.Add(this.packQuanttxt);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.SeaGreen;
            this.groupBox1.Location = new System.Drawing.Point(86, 422);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(643, 107);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quantity of item";
            // 
            // pieceQuanttxt
            // 
            this.pieceQuanttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pieceQuanttxt.ForeColor = System.Drawing.Color.Black;
            this.pieceQuanttxt.Location = new System.Drawing.Point(502, 70);
            this.pieceQuanttxt.Name = "pieceQuanttxt";
            this.pieceQuanttxt.Size = new System.Drawing.Size(100, 22);
            this.pieceQuanttxt.TabIndex = 29;
            this.pieceQuanttxt.Text = "0";
            this.pieceQuanttxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.pieceQuanttxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // pillQuanttxt
            // 
            this.pillQuanttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pillQuanttxt.ForeColor = System.Drawing.Color.Black;
            this.pillQuanttxt.Location = new System.Drawing.Point(502, 31);
            this.pillQuanttxt.Name = "pillQuanttxt";
            this.pillQuanttxt.Size = new System.Drawing.Size(100, 22);
            this.pillQuanttxt.TabIndex = 28;
            this.pillQuanttxt.Text = "0";
            this.pillQuanttxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.pillQuanttxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // tabQuanttxt
            // 
            this.tabQuanttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabQuanttxt.ForeColor = System.Drawing.Color.Black;
            this.tabQuanttxt.Location = new System.Drawing.Point(91, 70);
            this.tabQuanttxt.Name = "tabQuanttxt";
            this.tabQuanttxt.Size = new System.Drawing.Size(100, 22);
            this.tabQuanttxt.TabIndex = 27;
            this.tabQuanttxt.Text = "0";
            this.tabQuanttxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tabQuanttxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // packQuanttxt
            // 
            this.packQuanttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.packQuanttxt.ForeColor = System.Drawing.Color.Black;
            this.packQuanttxt.Location = new System.Drawing.Point(91, 31);
            this.packQuanttxt.Name = "packQuanttxt";
            this.packQuanttxt.Size = new System.Drawing.Size(100, 22);
            this.packQuanttxt.TabIndex = 26;
            this.packQuanttxt.Text = "0";
            this.packQuanttxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.packQuanttxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(439, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 16);
            this.label7.TabIndex = 3;
            this.label7.Text = "Piece";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Teal;
            this.label10.Location = new System.Drawing.Point(439, 34);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 16);
            this.label10.TabIndex = 2;
            this.label10.Text = "Pill";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(32, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Table";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(32, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Packet";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.SeaGreen;
            this.label11.Location = new System.Drawing.Point(22, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 20);
            this.label11.TabIndex = 25;
            this.label11.Text = "Unit";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Teal;
            this.label12.Location = new System.Drawing.Point(23, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 16);
            this.label12.TabIndex = 26;
            this.label12.Text = "Pill";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Teal;
            this.label13.Location = new System.Drawing.Point(23, 115);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 16);
            this.label13.TabIndex = 27;
            this.label13.Text = "Table";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Teal;
            this.label14.Location = new System.Drawing.Point(22, 155);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 16);
            this.label14.TabIndex = 28;
            this.label14.Text = "Packet";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.textBox9);
            this.groupBox2.Controls.Add(this.textBox10);
            this.groupBox2.Controls.Add(this.textBox11);
            this.groupBox2.Controls.Add(this.textBox12);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.piecenum);
            this.groupBox2.Controls.Add(this.packnum);
            this.groupBox2.Controls.Add(this.tabnum);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.pillnum);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox2.ForeColor = System.Drawing.Color.SeaGreen;
            this.groupBox2.Location = new System.Drawing.Point(24, 184);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(774, 230);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Price Details";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.sellDfltPiecerdb);
            this.groupBox4.Controls.Add(this.sellDfltPackrdb);
            this.groupBox4.Controls.Add(this.sellDfltTabrdb);
            this.groupBox4.Controls.Add(this.sellDfltPillrdb);
            this.groupBox4.Location = new System.Drawing.Point(661, 54);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(68, 169);
            this.groupBox4.TabIndex = 56;
            this.groupBox4.TabStop = false;
            // 
            // sellDfltPiecerdb
            // 
            this.sellDfltPiecerdb.AutoSize = true;
            this.sellDfltPiecerdb.Location = new System.Drawing.Point(27, 138);
            this.sellDfltPiecerdb.Name = "sellDfltPiecerdb";
            this.sellDfltPiecerdb.Size = new System.Drawing.Size(14, 13);
            this.sellDfltPiecerdb.TabIndex = 25;
            this.sellDfltPiecerdb.UseVisualStyleBackColor = true;
            // 
            // sellDfltPackrdb
            // 
            this.sellDfltPackrdb.AutoSize = true;
            this.sellDfltPackrdb.Checked = true;
            this.sellDfltPackrdb.Location = new System.Drawing.Point(27, 98);
            this.sellDfltPackrdb.Name = "sellDfltPackrdb";
            this.sellDfltPackrdb.Size = new System.Drawing.Size(14, 13);
            this.sellDfltPackrdb.TabIndex = 24;
            this.sellDfltPackrdb.TabStop = true;
            this.sellDfltPackrdb.UseVisualStyleBackColor = true;
            // 
            // sellDfltTabrdb
            // 
            this.sellDfltTabrdb.AutoSize = true;
            this.sellDfltTabrdb.Location = new System.Drawing.Point(27, 58);
            this.sellDfltTabrdb.Name = "sellDfltTabrdb";
            this.sellDfltTabrdb.Size = new System.Drawing.Size(14, 13);
            this.sellDfltTabrdb.TabIndex = 23;
            this.sellDfltTabrdb.UseVisualStyleBackColor = true;
            // 
            // sellDfltPillrdb
            // 
            this.sellDfltPillrdb.AutoSize = true;
            this.sellDfltPillrdb.Location = new System.Drawing.Point(27, 18);
            this.sellDfltPillrdb.Name = "sellDfltPillrdb";
            this.sellDfltPillrdb.Size = new System.Drawing.Size(14, 13);
            this.sellDfltPillrdb.TabIndex = 22;
            this.sellDfltPillrdb.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.buyDfltPiecerdb);
            this.groupBox3.Controls.Add(this.buyDfltPackrdb);
            this.groupBox3.Controls.Add(this.buyDfltTabrdb);
            this.groupBox3.Controls.Add(this.buyDfltPillrdb);
            this.groupBox3.Location = new System.Drawing.Point(524, 54);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(73, 169);
            this.groupBox3.TabIndex = 55;
            this.groupBox3.TabStop = false;
            // 
            // buyDfltPiecerdb
            // 
            this.buyDfltPiecerdb.AutoSize = true;
            this.buyDfltPiecerdb.Location = new System.Drawing.Point(29, 138);
            this.buyDfltPiecerdb.Name = "buyDfltPiecerdb";
            this.buyDfltPiecerdb.Size = new System.Drawing.Size(14, 13);
            this.buyDfltPiecerdb.TabIndex = 21;
            this.buyDfltPiecerdb.UseVisualStyleBackColor = true;
            // 
            // buyDfltPackrdb
            // 
            this.buyDfltPackrdb.AutoSize = true;
            this.buyDfltPackrdb.Checked = true;
            this.buyDfltPackrdb.Location = new System.Drawing.Point(29, 98);
            this.buyDfltPackrdb.Name = "buyDfltPackrdb";
            this.buyDfltPackrdb.Size = new System.Drawing.Size(14, 13);
            this.buyDfltPackrdb.TabIndex = 20;
            this.buyDfltPackrdb.TabStop = true;
            this.buyDfltPackrdb.UseVisualStyleBackColor = true;
            // 
            // buyDfltTabrdb
            // 
            this.buyDfltTabrdb.AutoSize = true;
            this.buyDfltTabrdb.Location = new System.Drawing.Point(29, 58);
            this.buyDfltTabrdb.Name = "buyDfltTabrdb";
            this.buyDfltTabrdb.Size = new System.Drawing.Size(14, 13);
            this.buyDfltTabrdb.TabIndex = 19;
            this.buyDfltTabrdb.UseVisualStyleBackColor = true;
            // 
            // buyDfltPillrdb
            // 
            this.buyDfltPillrdb.AutoSize = true;
            this.buyDfltPillrdb.Location = new System.Drawing.Point(29, 18);
            this.buyDfltPillrdb.Name = "buyDfltPillrdb";
            this.buyDfltPillrdb.Size = new System.Drawing.Size(14, 13);
            this.buyDfltPillrdb.TabIndex = 18;
            this.buyDfltPillrdb.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.SeaGreen;
            this.label20.Location = new System.Drawing.Point(639, 28);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(127, 20);
            this.label20.TabIndex = 54;
            this.label20.Text = "Selling Default";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.SeaGreen;
            this.label19.Location = new System.Drawing.Point(506, 28);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(127, 20);
            this.label19.TabIndex = 53;
            this.label19.Text = "Buying Default";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.SeaGreen;
            this.label18.Location = new System.Drawing.Point(379, 28);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 20);
            this.label18.TabIndex = 52;
            this.label18.Text = "Selling Price";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.SeaGreen;
            this.label17.Location = new System.Drawing.Point(234, 28);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(108, 20);
            this.label17.TabIndex = 51;
            this.label17.Text = "Buying Price";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.SeaGreen;
            this.label16.Location = new System.Drawing.Point(80, 28);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(149, 20);
            this.label16.TabIndex = 50;
            this.label16.Text = "Number of pieces";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.ForeColor = System.Drawing.Color.Black;
            this.textBox9.Location = new System.Drawing.Point(374, 191);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 22);
            this.textBox9.TabIndex = 17;
            this.textBox9.Text = "0";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.ForeColor = System.Drawing.Color.Black;
            this.textBox10.Location = new System.Drawing.Point(374, 152);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 22);
            this.textBox10.TabIndex = 16;
            this.textBox10.Text = "0";
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.ForeColor = System.Drawing.Color.Black;
            this.textBox11.Location = new System.Drawing.Point(374, 112);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 22);
            this.textBox11.TabIndex = 15;
            this.textBox11.Text = "0";
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox11.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.ForeColor = System.Drawing.Color.Black;
            this.textBox12.Location = new System.Drawing.Point(374, 72);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 22);
            this.textBox12.TabIndex = 14;
            this.textBox12.Text = "0";
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox12.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.ForeColor = System.Drawing.Color.Black;
            this.textBox8.Location = new System.Drawing.Point(230, 191);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 22);
            this.textBox8.TabIndex = 13;
            this.textBox8.Text = "0";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.ForeColor = System.Drawing.Color.Black;
            this.textBox7.Location = new System.Drawing.Point(229, 152);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 22);
            this.textBox7.TabIndex = 12;
            this.textBox7.Text = "0";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.ForeColor = System.Drawing.Color.Black;
            this.textBox6.Location = new System.Drawing.Point(230, 112);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 22);
            this.textBox6.TabIndex = 11;
            this.textBox6.Text = "0";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.ForeColor = System.Drawing.Color.Black;
            this.textBox5.Location = new System.Drawing.Point(229, 72);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 22);
            this.textBox5.TabIndex = 10;
            this.textBox5.Text = "0";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // piecenum
            // 
            this.piecenum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.piecenum.ForeColor = System.Drawing.Color.Black;
            this.piecenum.Location = new System.Drawing.Point(104, 192);
            this.piecenum.Name = "piecenum";
            this.piecenum.Size = new System.Drawing.Size(63, 22);
            this.piecenum.TabIndex = 9;
            this.piecenum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // packnum
            // 
            this.packnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.packnum.ForeColor = System.Drawing.Color.Black;
            this.packnum.Location = new System.Drawing.Point(104, 153);
            this.packnum.Name = "packnum";
            this.packnum.Size = new System.Drawing.Size(63, 22);
            this.packnum.TabIndex = 8;
            this.packnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabnum
            // 
            this.tabnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabnum.ForeColor = System.Drawing.Color.Black;
            this.tabnum.Location = new System.Drawing.Point(104, 113);
            this.tabnum.Name = "tabnum";
            this.tabnum.Size = new System.Drawing.Size(63, 22);
            this.tabnum.TabIndex = 7;
            this.tabnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Teal;
            this.label15.Location = new System.Drawing.Point(23, 194);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 16);
            this.label15.TabIndex = 30;
            this.label15.Text = "Piece";
            // 
            // pillnum
            // 
            this.pillnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pillnum.ForeColor = System.Drawing.Color.Black;
            this.pillnum.Location = new System.Drawing.Point(104, 73);
            this.pillnum.Name = "pillnum";
            this.pillnum.Size = new System.Drawing.Size(63, 22);
            this.pillnum.TabIndex = 6;
            this.pillnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.addItemTrdNametxt);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.addItemBartxt);
            this.groupBox5.Controls.Add(this.addItemScNametxt);
            this.groupBox5.Controls.Add(this.addItemCompcomb);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.addItemDelcomb);
            this.groupBox5.Controls.Add(this.addExDatedtp);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox5.ForeColor = System.Drawing.Color.SeaGreen;
            this.groupBox5.Location = new System.Drawing.Point(24, 44);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(774, 127);
            this.groupBox5.TabIndex = 30;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Item General Info";
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label21.ForeColor = System.Drawing.Color.Teal;
            this.label21.Location = new System.Drawing.Point(351, 9);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 24);
            this.label21.TabIndex = 22;
            this.label21.Text = "Add Items";
            // 
            // AddItemFrm
            // 
            this.AcceptButton = this.addItemAddbtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.CancelButton = this.addItemCanclebtn;
            this.ClientSize = new System.Drawing.Size(810, 587);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.addItemCanclebtn);
            this.Controls.Add(this.addItemAddbtn);
            this.Controls.Add(this.groupBox5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "AddItemFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Items";
            this.Load += new System.EventHandler(this.AddItemFrm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.piecenum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packnum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabnum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pillnum)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button addItemAddbtn;
        private System.Windows.Forms.Button addItemCanclebtn;
        private System.Windows.Forms.TextBox addItemBartxt;
        private System.Windows.Forms.TextBox addItemScNametxt;
        private System.Windows.Forms.ComboBox addItemCompcomb;
        private System.Windows.Forms.DateTimePicker addExDatedtp;
        private System.Windows.Forms.TextBox addItemTrdNametxt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox addItemDelcomb;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox pieceQuanttxt;
        private System.Windows.Forms.TextBox pillQuanttxt;
        private System.Windows.Forms.TextBox tabQuanttxt;
        private System.Windows.Forms.TextBox packQuanttxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.NumericUpDown piecenum;
        private System.Windows.Forms.NumericUpDown packnum;
        private System.Windows.Forms.NumericUpDown tabnum;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown pillnum;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton sellDfltPiecerdb;
        private System.Windows.Forms.RadioButton sellDfltPackrdb;
        private System.Windows.Forms.RadioButton sellDfltTabrdb;
        private System.Windows.Forms.RadioButton sellDfltPillrdb;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton buyDfltPiecerdb;
        private System.Windows.Forms.RadioButton buyDfltPackrdb;
        private System.Windows.Forms.RadioButton buyDfltTabrdb;
        private System.Windows.Forms.RadioButton buyDfltPillrdb;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label21;
    }
}